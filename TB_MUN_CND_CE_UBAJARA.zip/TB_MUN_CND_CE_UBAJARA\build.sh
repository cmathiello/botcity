#!/bin/bash

zip -r "TB_MUN_CND_CE_UBAJARA.zip" * -x "TB_MUN_CND_CE_UBAJARA.zip"